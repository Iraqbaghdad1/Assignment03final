package com.example.ahmedmohammed_comp304lab_ex1.data

object Constant {
    val apiKey = "260828c2c3d5457a826182439242409"
}