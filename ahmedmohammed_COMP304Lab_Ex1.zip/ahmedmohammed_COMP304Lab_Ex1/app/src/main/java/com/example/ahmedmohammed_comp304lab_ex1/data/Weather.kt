package com.example.ahmedmohammed_comp304lab_ex1.data

import androidx.room.Dao
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity("weather")
data class Weather(
    @PrimaryKey(autoGenerate = true) val id : Int = 0,
    val location:String,
    val country : String,
    val condition : String,
    val temp_c:String,
    val region:String
)