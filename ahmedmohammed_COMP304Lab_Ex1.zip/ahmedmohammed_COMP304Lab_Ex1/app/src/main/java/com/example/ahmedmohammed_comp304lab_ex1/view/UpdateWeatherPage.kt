package com.example.ahmedmohammed_comp304lab_ex1.view

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.ahmedmohammed_comp304lab_ex1.navigation.Screens
import com.example.ahmedmohammed_comp304lab_ex1.viewmodel.WeatherViewModel


@Composable
fun UpdateWeatherPage(
    modifier: Modifier = Modifier,
    location: String,
    weatherViewModel: WeatherViewModel,
    navController: NavController
) {

    LaunchedEffect(true) {

        weatherViewModel.fetchWeatherByLocation(location = location)

    }

    val weatherData by weatherViewModel.singleWeather.collectAsState()



    var _location by remember {
        mutableStateOf("")
    }
    var _country by remember {
        mutableStateOf("")
    }

    var _region by remember {
        mutableStateOf("")
    }

    var _condition by remember {
        mutableStateOf("")
    }

    var _temperature by remember {
        mutableStateOf("")
    }

    weatherData?.let {
        if (_temperature.isEmpty()) _temperature = it.temp_c
        if (_region.isEmpty()) _region = it.region
        if (_condition.isEmpty()) _condition= it.condition
        if (_country.isEmpty()) _country = it.country
        if (_location.isEmpty()) _location = it.location

    }

    Column(
        modifier = modifier
            .padding(16.dp)
            .fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text(text = "Update Weather Data", style = MaterialTheme.typography.titleMedium)


        OutlinedTextField(
            value = _location,
            onValueChange = {_location = it},
            label = { Text("Location") },
            modifier = Modifier.fillMaxWidth()
        )


        OutlinedTextField(
            value = _region,
            onValueChange = { _region = it },
            label = { Text("Region") },
            modifier = Modifier.fillMaxWidth()
        )


        OutlinedTextField(
            value = _country,
            onValueChange = { _country = it },
            label = { Text("Country") },
            modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
            value = _condition,
            onValueChange = { _condition = it },
            label = { Text("Condition") },
            modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
            value = _temperature,
            onValueChange = { _temperature = it },
            label = { Text("Temperature") },
            modifier = Modifier.fillMaxWidth()
        )


        Button(
            onClick = {

                      weatherViewModel.updateWeatherRoomData(location = _location , country = _country , condition = _condition , temp_c = _temperature , region = _region)
                        navController.navigate(Screens.SavedWeather.route)


            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Update Weather")
        }
    }
}
