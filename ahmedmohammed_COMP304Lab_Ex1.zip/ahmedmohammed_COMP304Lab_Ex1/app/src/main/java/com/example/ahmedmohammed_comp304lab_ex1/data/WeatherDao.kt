package com.example.ahmedmohammed_comp304lab_ex1.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update

@Dao
interface WeatherDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWeather(weather: Weather)


    @Query("""
        UPDATE weather
        SET location = :location,
            country = :country,
            condition = :condition,
            temp_c = :tempC,
            region = :region
        WHERE location = :location
    """)
    suspend fun updateWeather(location: String, country: String, condition: String, tempC: String, region: String)

    @Query("DELETE FROM weather WHERE location = :location")
    suspend fun deleteWeather(location: String)


    @Query("DELETE FROM weather")
    suspend fun deleteAllWeather()


    @Query("SELECT * FROM weather")
    suspend fun getAllWeather(): List<Weather>


    @Query("SELECT * FROM weather WHERE location = :location LIMIT 1")
    suspend fun getWeatherByLocation(location: String): Weather?


}