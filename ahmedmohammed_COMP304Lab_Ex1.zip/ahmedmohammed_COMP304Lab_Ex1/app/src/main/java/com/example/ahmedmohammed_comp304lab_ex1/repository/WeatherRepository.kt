package com.example.ahmedmohammed_comp304lab_ex1.repository

import com.example.ahmedmohammed_comp304lab_ex1.data.WeatherDao
import com.example.ahmedmohammed_comp304lab_ex1.model.WeatherModel
import com.example.ahmed1.remote.WeatherApi
import com.example.ahmedmohammed_comp304lab_ex1.data.Weather
import com.example.ahmedmohammed_comp304lab_ex1.remote.NetworkResponse
import javax.inject.Inject

class WeatherRepository @Inject constructor(
    private val api: WeatherApi,
    private val weatherDao: WeatherDao
) {

//    getting data from the weather api
    suspend fun fetchWeatherData(apiKey: String, location: String): NetworkResponse<WeatherModel> {
        return try {
            NetworkResponse.Loading
            val response = api.getWeather(apiKey, location)

            if (response.isSuccessful) {
                response.body()?.let {

                    NetworkResponse.Success(it)

                } ?: NetworkResponse.Error("Response body is null")
            } else {
                NetworkResponse.Error("API call failed with error code: ${response.code()}")
            }
        } catch (e: Exception) {
            NetworkResponse.Error("Exception occurred: ${e.localizedMessage}")
        }
    }

//    inserting data to roomDB through weatherDao

    suspend fun saveWeatherData(weather: Weather) {
        weatherDao.insertWeather(weather)
    }

    suspend fun getWeatherRoom() : List<Weather> = weatherDao.getAllWeather()

//   updating data cached in room db
    suspend fun updateWeatherData(location: String, country: String, condition: String, tempC: String, region: String) {
        weatherDao.updateWeather(
            location = location,
            country = country,
            condition = condition,
            tempC = tempC,
            region = region
        )
    }
// Deleting data saved on the weather table in room
    suspend fun deleteWeatherData(location: String) {
        weatherDao.deleteWeather(location = location)
    }

    suspend fun getWeatherByLocation(location: String) : Weather? = weatherDao.getWeatherByLocation(location)
}
