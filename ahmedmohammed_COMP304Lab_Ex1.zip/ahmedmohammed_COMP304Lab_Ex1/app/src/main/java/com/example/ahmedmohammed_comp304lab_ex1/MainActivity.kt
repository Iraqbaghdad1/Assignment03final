package com.example.ahmedmohammed_comp304lab_ex1

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.navigation.compose.rememberNavController
import com.example.ahmedmohammed_comp304lab_ex1.data.NavItem
import com.example.ahmedmohammed_comp304lab_ex1.navigation.Screens
import com.example.ahmedmohammed_comp304lab_ex1.navigation.SetUpNavHost
import com.example.ahmedmohammed_comp304lab_ex1.ui.theme.Ahmedmohammed_COMP304Lab_Ex1Theme
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    @OptIn(ExperimentalMaterial3Api::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            Ahmedmohammed_COMP304Lab_Ex1Theme {
                val navController = rememberNavController()
                val items = listOf(
                    NavItem(label = "Search" , icon = Icons.Default.Search , route =  Screens.WeatherPage.route),
                    NavItem(label = "Saved Data" , icon = Icons.Default.List , route = Screens.SavedWeather.route)
                )
                var selectedIndex by remember {
                    mutableStateOf(0)
                }
                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    bottomBar = {
                        NavigationBar {
                            items.forEachIndexed { index, navItem ->
                                NavigationBarItem(
                                    selected = selectedIndex == index,
                                    label = {
                                        Text(text = navItem.label)
                                    },
                                    onClick = {
                                        selectedIndex = index

                                        navController.navigate(navItem.route){
                                            popUpTo(navController.graph.startDestinationId) {
                                                saveState = true
                                            }
                                            launchSingleTop = true
                                            restoreState = true
                                        }

                                    },
                                    icon = {
                                        Icon(imageVector = navItem.icon, contentDescription = null)
                                    })
                            }
                        }
                    },
                    topBar = {
                        TopAppBar(
                            title = {
                                Text(
                                    text = "Weather App",
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.titleLarge,
                                    color = MaterialTheme.colorScheme.onPrimary
                                )
                            },

                            colors = TopAppBarDefaults.smallTopAppBarColors(
                                containerColor = MaterialTheme.colorScheme.primary,
                                titleContentColor = MaterialTheme.colorScheme.onPrimary
                            ),
                            modifier = Modifier.statusBarsPadding() // Ensures the bar is below the status bar
                        )
                    }
                ) { innerPadding ->
                    SetUpNavHost(navController = navController, modifier = Modifier.padding(innerPadding))
                }
            }
        }
    }
}
