package com.example.ahmedmohammed_comp304lab_ex1.navigation

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.example.ahmedmohammed_comp304lab_ex1.view.SavedWeatherPage
import com.example.ahmedmohammed_comp304lab_ex1.view.UpdateWeatherPage
import com.example.ahmedmohammed_comp304lab_ex1.view.WeatherDetailPage
import com.example.ahmedmohammed_comp304lab_ex1.view.WeatherPage
import com.example.ahmedmohammed_comp304lab_ex1.viewmodel.WeatherViewModel

@Composable
fun SetUpNavHost(navController: NavHostController, modifier: Modifier = Modifier) {
    NavHost(
        navController = navController,
        startDestination = Screens.WeatherPage.route,
        modifier = modifier
    ) {
        composable(Screens.WeatherPage.route) {
            val weatherViewModel = hiltViewModel<WeatherViewModel>()
            WeatherPage(
                weatherViewModel = weatherViewModel,
                navController = navController
            )
        }
        composable(Screens.WeatherDetail.route + "/{location}") { backStackEntry ->
            val weatherViewModel = hiltViewModel<WeatherViewModel>()
            val locationName = backStackEntry.arguments?.getString("location") ?: ""

                WeatherDetailPage(
                    location = locationName,
                    weatherViewModel = weatherViewModel
                )

        }

        composable(Screens.SavedWeather.route) {
            val weatherViewModel = hiltViewModel<WeatherViewModel>()
           SavedWeatherPage(weatherViewModel = weatherViewModel , navController = navController)
        }

        composable(Screens.UpdateWeather.route + "/{location}") {backStackEntry ->
            val location = backStackEntry.arguments?.getString("location") ?: ""
            val weatherViewModel = hiltViewModel<WeatherViewModel>()
            UpdateWeatherPage(location = location , weatherViewModel = weatherViewModel , navController = navController)
        }
    }
}
