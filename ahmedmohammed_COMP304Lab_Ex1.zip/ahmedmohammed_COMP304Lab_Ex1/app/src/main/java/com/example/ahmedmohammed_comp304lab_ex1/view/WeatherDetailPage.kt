package com.example.ahmedmohammed_comp304lab_ex1.view

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.ahmedmohammed_comp304lab_ex1.data.Constant
import com.example.ahmedmohammed_comp304lab_ex1.remote.NetworkResponse
import com.example.ahmedmohammed_comp304lab_ex1.viewmodel.WeatherViewModel


@Composable
fun WeatherDetailPage(location:String , weatherViewModel: WeatherViewModel) {

    val weatherState by weatherViewModel.weatherState.collectAsState()

    LaunchedEffect(true) {

        weatherViewModel.fetchWeatherData(apiKey = Constant.apiKey , location = location)

    }

    when (val result = weatherState) {

        is NetworkResponse.Success -> {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp)
                    .padding(vertical = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.Bottom
                ) {
                    Icon(
                        imageVector = Icons.Default.LocationOn,
                        contentDescription = "Location icon",
                        modifier = Modifier.size(40.dp)
                    )
                    Text(text = result.data.location.name, fontSize = 30.sp)
                    Spacer(modifier = Modifier.width(8.dp))

                }

                Text(text = result.data.location.country, fontSize = 18.sp, color = Color.Gray)

                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = " ${result.data.current.temp_c} ° c",
                    fontSize = 56.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )

                AsyncImage(
                    modifier = Modifier.size(160.dp),
                    model = "https:${result.data.current.condition.icon}".replace("64x64","128x128"),
                    contentDescription = "Condition icon"
                )
                Text(
                    text = result.data.current.condition.text,
                    fontSize = 20.sp,
                    textAlign = TextAlign.Center,
                    color = Color.Gray
                )

            }
        }

        is NetworkResponse.Loading -> {
            Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.Center , horizontalAlignment = Alignment.CenterHorizontally) {
                CircularProgressIndicator()
            }

        }
        is NetworkResponse.Error -> {
            Text(text = "Error: ${result.message}", color = Color.Red)
        }
        null -> {

        }
    }


}


