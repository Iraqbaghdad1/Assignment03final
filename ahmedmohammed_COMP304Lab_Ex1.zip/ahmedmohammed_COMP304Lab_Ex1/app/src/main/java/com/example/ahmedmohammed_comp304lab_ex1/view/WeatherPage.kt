package com.example.ahmedmohammed_comp304lab_ex1.view

import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.ahmedmohammed_comp304lab_ex1.data.Constant
import com.example.ahmedmohammed_comp304lab_ex1.data.Weather
import com.example.ahmedmohammed_comp304lab_ex1.navigation.Screens
import com.example.ahmedmohammed_comp304lab_ex1.remote.NetworkResponse

import com.example.ahmedmohammed_comp304lab_ex1.viewmodel.WeatherViewModel


@Composable
fun WeatherPage(modifier: Modifier = Modifier, weatherViewModel: WeatherViewModel , navController: NavController) {
    val context = LocalContext.current
    val weatherState by weatherViewModel.weatherState.collectAsState()
    val savedSuccess by weatherViewModel.savedSuccess.collectAsState()

    var city by remember { mutableStateOf("") }
    val keyboardController = LocalSoftwareKeyboardController.current

    LaunchedEffect(savedSuccess) {
        if (savedSuccess) {
            Toast.makeText(context, "Data Saved Locally!!", Toast.LENGTH_SHORT).show()
            weatherViewModel.clearSavedSuccess()

        }
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(18.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Search input
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            OutlinedTextField(
                modifier = Modifier.weight(1f),
                value = city,
                onValueChange = { city = it },
                label = { Text(text = "Search for any location") }
            )
            IconButton(
                onClick = {
                    weatherViewModel.fetchWeatherData(apiKey = Constant.apiKey, location = city)
                    keyboardController?.hide()
                }
            ) {
                Icon(
                    imageVector = Icons.Default.Search,
                    contentDescription = "Search for any location"
                )
            }
        }

        when (val result = weatherState) {

            is NetworkResponse.Success -> {
                val weather = Weather(
                    location = result.data.location.name,
                    condition = result.data.current.condition.text,
                    country = result.data.location.country,
                    temp_c = result.data.current.temp_c.toString(),
                    region = result.data.location.region
                )
                WeatherCard(weather = weather, onSaveClick = {
                    weatherViewModel.saveWeatherData(weather = weather)

                } ,
                    onDetailsClick = {
                   navController.navigate(route = Screens.WeatherDetail.route + "/${result.data.location.name}")
                })
            }

            is NetworkResponse.Loading -> {
                CircularProgressIndicator()
            }
            is NetworkResponse.Error -> {
                Text(text = "Error: ${result.message}", color = Color.Red)
            }
            null -> {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                        .wrapContentHeight(),
                    shape = RoundedCornerShape(12.dp),
                    elevation = CardDefaults.cardElevation(8.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                    ) {
                        Text(
                            text = "Search Location e.g London \uD83D\uDD0D",
                            fontWeight = FontWeight.ExtraBold,
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.primary
                        )

                        }
                    }
                }
            }
        }
    }


