package com.example.ahmedmohammed_comp304lab_ex1.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.ahmedmohammed_comp304lab_ex1.data.Weather
import com.example.ahmedmohammed_comp304lab_ex1.model.WeatherModel
import com.example.ahmedmohammed_comp304lab_ex1.remote.NetworkResponse
import com.example.ahmedmohammed_comp304lab_ex1.repository.WeatherRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject
import javax.inject.Singleton

@HiltViewModel
class WeatherViewModel @Inject constructor(
    private val weatherRepository: WeatherRepository
) : ViewModel() {

    private val _weatherState = MutableStateFlow<NetworkResponse<WeatherModel>?>(null)
    val weatherState: StateFlow<NetworkResponse<WeatherModel>?> get() = _weatherState

    private val _localWeather = MutableStateFlow<List<Weather>>(emptyList())
    val localWeather: StateFlow<List<Weather>> get() = _localWeather

    private val _savedSuccess = MutableStateFlow<Boolean>(false)
    val savedSuccess: StateFlow<Boolean> get() = _savedSuccess

    private val _singleWeather = MutableStateFlow<Weather?>(null)
    val singleWeather: StateFlow<Weather?> get() = _singleWeather

//    fetching data from a remote api

    fun fetchWeatherData(apiKey: String, location: String) {
        viewModelScope.launch {

            try {
                _weatherState.value = NetworkResponse.Loading
                val response = weatherRepository.fetchWeatherData(apiKey, location)
                _weatherState.value = response
            } catch (e: Exception) {
                _weatherState.value =
                    NetworkResponse.Error(e.message ?: "An unexpected error occurred")
            }
        }
    }


// Inserting into weather table in roomDb
    fun saveWeatherData(weather: Weather) {
        viewModelScope.launch {
            weatherRepository.saveWeatherData(weather)
            _savedSuccess.value = true
        }
    }

//    fetching all the weather data saved in roomDB
    fun getWeatherFromRoom() {
        viewModelScope.launch {
            try {
                val weatherData = weatherRepository.getWeatherRoom()
                _localWeather.value = weatherData
            } catch (e: Exception) {
                e.message?.let { Log.d("Error is: " , it) }
            }

        }

    }
    fun fetchWeatherByLocation(location: String){
        viewModelScope.launch {
            _singleWeather.value = weatherRepository.getWeatherByLocation(location)
        }
    }

//    Updating saved data in room db
    fun updateWeatherRoomData(location: String , country:String , region:String , temp_c: String , condition: String){
        viewModelScope.launch {
            weatherRepository.updateWeatherData(location = location , country = country , region=region , tempC = temp_c , condition = condition)
        }
    }


//   removing weather data fro m room
     fun deleteWeatherFromRoom(location: String){
        viewModelScope.launch {
            weatherRepository.deleteWeatherData(location = location)
            getWeatherFromRoom()
        }

    }

    fun clearSavedSuccess(){
        _savedSuccess.value = false
    }
}