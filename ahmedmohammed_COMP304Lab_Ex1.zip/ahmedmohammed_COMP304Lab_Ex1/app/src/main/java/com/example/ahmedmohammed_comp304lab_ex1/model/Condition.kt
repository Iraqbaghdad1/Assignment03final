package com.example.ahmedmohammed_comp304lab_ex1.model

data class Condition(
    val code: Int,
    val icon: String,
    val text: String
)