package com.example.ahmedmohammed_comp304lab_ex1.model

import com.example.ahmedmohammed_comp304lab_ex1.model.Current
import com.example.ahmedmohammed_comp304lab_ex1.model.Location

data class WeatherModel(
    val current: Current,
    val location: Location
)