package com.example.ahmedmohammed_comp304lab_ex1.data

import androidx.room.Database
import androidx.room.RoomDatabase
import com.example.ahmedmohammed_comp304lab_ex1.data.WeatherDao
import javax.inject.Singleton

@Singleton
@Database(entities = [Weather::class] , version = 3)
abstract class WeatherDatabase : RoomDatabase() {

    abstract fun getWeatherDao() : WeatherDao

}