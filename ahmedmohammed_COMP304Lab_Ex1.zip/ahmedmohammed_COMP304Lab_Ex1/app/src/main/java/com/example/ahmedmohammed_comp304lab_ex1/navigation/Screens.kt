package com.example.ahmedmohammed_comp304lab_ex1.navigation

sealed class Screens(val route:String) {

    data object WeatherPage : Screens(route = "weather_page")
    data object WeatherDetail : Screens(route = "weather_detail_page")
    data object SavedWeather : Screens(route = "saved_weather_data")
    data object UpdateWeather : Screens(route = "update_weather_page")

}